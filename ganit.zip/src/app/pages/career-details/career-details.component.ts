import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-career-details',
  templateUrl: './career-details.component.html',
  styleUrls: ['./career-details.component.scss']
})
export class CareerDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

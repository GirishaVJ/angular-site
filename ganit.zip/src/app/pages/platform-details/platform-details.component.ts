import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-platform-details',
  templateUrl: './platform-details.component.html',
  styleUrls: ['./platform-details.component.scss']
})
export class PlatformDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contat-us',
  templateUrl: './contat-us.component.html',
  styleUrls: ['./contat-us.component.scss']
})
export class ContatUsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

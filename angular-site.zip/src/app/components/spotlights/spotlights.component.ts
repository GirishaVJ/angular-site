import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spotlights',
  templateUrl: './spotlights.component.html',
  styleUrls: ['./spotlights.component.scss']
})
export class SpotlightsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

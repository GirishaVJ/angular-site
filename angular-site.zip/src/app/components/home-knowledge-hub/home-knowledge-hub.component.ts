import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-knowledge-hub',
  templateUrl: './home-knowledge-hub.component.html',
  styleUrls: ['./home-knowledge-hub.component.scss']
})
export class HomeKnowledgeHubComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

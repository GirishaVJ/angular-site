import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-achievments-details',
  templateUrl: './achievments-details.component.html',
  styleUrls: ['./achievments-details.component.scss']
})
export class AchievmentsDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

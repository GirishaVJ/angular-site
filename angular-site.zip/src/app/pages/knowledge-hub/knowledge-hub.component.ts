import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-knowledge-hub',
  templateUrl: './knowledge-hub.component.html',
  styleUrls: ['./knowledge-hub.component.scss']
})
export class KnowledgeHubComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
